﻿#Requires -Version 3.0
#Requires -RunAsAdministrator

<#
    .SYNOPSIS
     PSWrapper for Application Deployment
	.Description
     Use the XML (PSApplication.xml) file to give the script all necessary variables. 
#>

#region -----------------------------------------------------------[Pre-Initialisations]------------------------------------------------------------

    $StartPS = (Get-Date)
    $scriptName = Split-Path $MyInvocation.MyCommand -Leaf
    $scriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    [XML]$scriptFile = Get-Content -Path "$scriptDirectory\PSApplication.xml"

#endregion
#region -----------------------------------------------------------[Functions]----------------------------------------------------------------------

    Import-Module ($scriptDirectory+"\PSM\hp_Log.psm1") -Force

#endregion
#region -----------------------------------------------------------[Main-Initialisations]-----------------------------------------------------------

    $Vendor = $scriptFile.Application.Vendor
    $Product = $scriptFile.Application.Product
    $Version = $scriptFile.Application.Version

    $LogPath = "$env:systemroot\Logs\Software"
    $LogPS = "$LogPath\$Vendor-$Product-$Version.log"
    $LogAPP = "$LogPath\Debug\$Vendor-$Product-$Version.log"
    $Global:Log_Path_hp = $LogPS

    $InstallerName = $scriptFile.Application.InstallerName
    $UnattendedArgs = $scriptFile.Application.UnattendedArgs 

#endregion
#region -----------------------------------------------------------[Execution]----------------------------------------------------------------------

    # Start Message
    Write-Log_hp -Message "Starting Installation of $Vendor $Product $Version" -Component $scriptName -Status Info
    <#
    # Detect EXE or MSI and RUN them with the Unattended Arguments
    Switch -Wildcard ($InstallerName){

        "*.exe" {$RUN = Start-Process -Wait -FilePath ($scriptDirectory + "\Files\" + $InstallerName) -ArgumentList $UnattendedArgs -Passthru}
        "*.msi" {$RUN = Start-Process -Wait -FilePath ("$env:systemroot\system32\msiexec.exe") -ArgumentList "/i ""$scriptDirectory\Files\$InstallerName"" /l*v ""$LogAPP"" $UnattendedArgs" -Passthru}
        Default {Write-Log_hp -Message "Keine EXE oder MSI zum ausführen" -Component $scriptName -Status Error}

    }
    #>
    # Ext Message from Installation
	# Write-Log_hp -Message "Exit Code: $($RUN.ExitCode)" -Component $scriptName -Status Info

	# Some Costomization
	# Write-Log_hp -Message "Customization" -Component $scriptName -Status Info

    $CTX_PVS_TargetDeivce = "Provisioning Services Target Device" 
    $FolderScript="$env:ProgramFiles\Citrix\PVS Device Prep"
    $FolderLINK="$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Administrative Tools"

    #Check for Installed Citrix Target Device
    IF (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | ? {$_.DisplayName -like "*$CTX_PVS_TargetDeivce*"})
    {

        # Create Folder if not exists
        if (!(Test-Path -path $FolderScript)) {New-Item $FolderScript -Type Directory}

        # Copy Files
        Copy-Item "$scriptDirectory\Files\Script\*" -Destination "$FolderScript" -Recurse | Out-Null
        Copy-Item "$scriptDirectory\Files\Link\*.*" -Destination "$FolderLINK"  -Recurse | Out-Null

    }
    Else
    {

        $Msg = "Citrix Target Device Installation konnte nicht gefunden werden!"
        Write-Log_hp -Message $Msg -Component $scriptName -Status Info

    }
	# Do something

#endregion
#region -----------------------------------------------------------[End]----------------------------------------------------------------------------

    $EndPS = (Get-Date)
    Write-Log_hp -Message "Elapsed Time: $([math]::Round((($EndPS-$StartPS).TotalMinutes),2)) Minutes" -Component $scriptName -Status Info

#endregion